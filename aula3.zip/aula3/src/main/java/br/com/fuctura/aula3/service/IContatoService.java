package br.com.fuctura.aula3.service;

import br.com.fuctura.aula3.dto.ContatoRequestDTO;

public interface IContatoService {
	void salvar(ContatoRequestDTO contato);
}
