package br.com.fuctura.aula3.dto;


public class ContatoResponseDTO {
	private String mensagem;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
}
