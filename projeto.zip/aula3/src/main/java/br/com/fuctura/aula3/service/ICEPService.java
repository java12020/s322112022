package br.com.fuctura.aula3.service;

import br.com.fuctura.aula3.dto.EnderecoIBGEDTO;

public interface ICEPService {
	EnderecoIBGEDTO getEnderecoIBGEDTO(String cep);
}
