package br.com.fuctura.aula3.dto;

public class ContatoDTO {

	private String nome;
	private Double altura;
	private Integer idade;
	
	public ContatoDTO(String nome, Double altura, Integer idade) {
		this.nome = nome;
		this.altura = altura;
		this.idade = idade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Double getAltura() {
		return altura;
	}

	public void setAltura(Double altura) {
		this.altura = altura;
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}
}
