package br.com.fuctura.aula3.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import br.com.fuctura.aula3.dto.ContatoRequestDTO;
import br.com.fuctura.aula3.entity.ContatoEntity;
import br.com.fuctura.aula3.mapper.AulaMapper;
import br.com.fuctura.aula3.repository.ContatoRepository;
import br.com.fuctura.aula3.service.ICEPService;
import br.com.fuctura.aula3.service.IContatoService;

@Service
@Qualifier("H2")
public class ContatoServiceH2Impl implements IContatoService {
	@Autowired
	private ContatoRepository repository;
	
	@Autowired
	private AulaMapper mapper;
	
	@Override
	public void salvar(ContatoRequestDTO contato) {
				
		//mapear ContatoRequestDTO -> ContatoEntity
		ContatoEntity entidade = new ContatoEntity();
		entidade.setNome(contato.getNome());
		entidade.setAltura(contato.getAltura());
		entidade.setIdade(contato.getIdade());
		
		repository.save(entidade);
	}

	@Override
	public List<ContatoRequestDTO> obterTodos() {
		return converterLista(repository.findAll());
	}

	@Override
	public List<ContatoRequestDTO> obter(String nome) {
		return converterLista(repository.findContatoByNome(nome));
	}
	
	private ContatoRequestDTO converterParaContatoRequestDTO(ContatoEntity entrada) {
		var saida = new ContatoRequestDTO();
		saida.setNome(entrada.getNome());
		saida.setAltura(entrada.getAltura());
		saida.setIdade(entrada.getIdade());
		return saida;
	}

	@Override
	public void atualizar(ContatoRequestDTO contato) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void excluir(String nome) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ContatoRequestDTO> consultarPorAlturaEntre(Double min, Double max) {
		var resultadoDaConsulta = repository.findContatoByAlturaBetween(min, max);
		
		return converterLista(resultadoDaConsulta);
	}

	@Override
	public List<ContatoRequestDTO> consultarPorIdadeIn(List<Integer> valores) {
		var resultadoDaConsulta = repository.findContatoByIdadeInOrderByIdadeDesc(valores);
		
		return converterLista(resultadoDaConsulta);
	}
	private List<ContatoRequestDTO> converterLista(List<ContatoEntity> resultadoDaConsulta) {
		var listaDTO = new ArrayList<ContatoRequestDTO>();
		
		if(resultadoDaConsulta != null) {
			for(ContatoEntity e : resultadoDaConsulta) {
				var dto = mapper.toContatoRequestDTO(e);
				listaDTO.add(dto);
			}
		}
			
		return listaDTO;
	}

}
