package br.com.fuctura.aula3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.fuctura.aula3.dto.ContatoRequestDTO;
import br.com.fuctura.aula3.dto.ContatoResponseDTO;
import br.com.fuctura.aula3.dto.NomeRequestDTO;
import br.com.fuctura.aula3.service.IContatoService;

@RestController
@RequestMapping("/contato")
public class ContatoController {

	private final IContatoService service;
	
	
	@Autowired
	public ContatoController(@Qualifier("H2")  IContatoService service	) {
		this.service = service;
	}
	
	@PostMapping("/cadastrar")
	public ResponseEntity<ContatoResponseDTO> post(@RequestBody ContatoRequestDTO request) {
		service.salvar(request);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}
	
	@GetMapping("/pesquisar")
	public ResponseEntity<List<ContatoRequestDTO>> listarTodos() {
		return ResponseEntity.ok(service.obterTodos());
	}
	
	@GetMapping("/pesquisar/{nome}")
	public ResponseEntity<List<ContatoRequestDTO>> listar(@PathVariable String nome) {	
		return ResponseEntity.ok(service.obter(nome));
	}
	
	@GetMapping("/pesquisar/nome")
	public ResponseEntity<List<ContatoRequestDTO>> getByNome(NomeRequestDTO request) {
		return ResponseEntity.ok(service.obter(request.getNome()));
	}
}
