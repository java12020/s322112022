package br.com.fuctura.aula3.service;

import java.util.List;

import br.com.fuctura.aula3.dto.ContatoRequestDTO;
import br.com.fuctura.aula3.entity.ContatoEntity;

public interface IContatoService {
	void salvar(ContatoRequestDTO contato);
	List<ContatoRequestDTO> obterTodos(); 
	List<ContatoRequestDTO> obter(String nome);
	void atualizar(ContatoRequestDTO contato);
	void excluir(String nome);
	List<ContatoRequestDTO> consultarPorAlturaEntre(Double min, Double max);
	
	List<ContatoRequestDTO> consultarPorIdadeIn(List<Integer> valores);	
}
