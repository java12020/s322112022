package br.com.fuctura.aula3.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.com.fuctura.aula3.dto.EnderecoIBGEDTO;
import br.com.fuctura.aula3.service.ICEPService;

@Service
public class CEPServiceImpl implements ICEPService {

	private final RestTemplate client;

	public CEPServiceImpl(RestTemplate client) {
		this.client = client;
	}

	@Override
	public EnderecoIBGEDTO getEnderecoIBGEDTO(String cep) {
		var sb = new StringBuilder("https://viacep.com.br/ws/")
					.append(cep)
					.append("/json/");
		
		var response = client.getForEntity(sb.toString(), EnderecoIBGEDTO.class);
		return response.hasBody() ? response.getBody() : null;
	}
	
}
