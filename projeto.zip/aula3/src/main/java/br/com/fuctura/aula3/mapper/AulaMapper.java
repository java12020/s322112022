package br.com.fuctura.aula3.mapper;

import org.mapstruct.Mapper;

import br.com.fuctura.aula3.dto.ContatoDTO;
import br.com.fuctura.aula3.dto.ContatoRequestDTO;
import br.com.fuctura.aula3.entity.ContatoEntity;


@Mapper(componentModel="spring")
public interface AulaMapper {
	
	//ContatoDTO -> ContatoRequestDTO
	ContatoRequestDTO toContatoRequestDTO(ContatoDTO entrada);
	
	ContatoRequestDTO toContatoRequestDTO(ContatoEntity entrada);
	
}
