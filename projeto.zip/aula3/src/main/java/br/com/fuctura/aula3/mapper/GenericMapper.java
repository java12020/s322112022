package br.com.fuctura.aula3.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import br.com.fuctura.aula3.dto.ContatoRequestDTO;
import br.com.fuctura.aula3.dto.EnderecoDTO;
import br.com.fuctura.aula3.entity.ContatoEntity;

@Mapper(componentModel = "spring")
public interface GenericMapper {
	
	@Mapping(target = "numero", source = "dto.endereco.numero")
	@Mapping(target = "logradouro", source = "dto.endereco.logradouro")
	@Mapping(target = "cep", source = "dto.endereco.cep")
	EnderecoDTO toEnderecoDTO(ContatoRequestDTO dto);
	
	ContatoEntity toContatoEntity(ContatoRequestDTO dto);	
}
