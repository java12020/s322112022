package br.com.fuctura.aula3.dto;

public class NomeRequestDTO {

	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
