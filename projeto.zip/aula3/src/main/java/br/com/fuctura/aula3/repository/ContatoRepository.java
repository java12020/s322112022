package br.com.fuctura.aula3.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.fuctura.aula3.dto.ContatoDTO;
import br.com.fuctura.aula3.entity.ContatoEntity;

@Repository
public interface ContatoRepository extends JpaRepository<ContatoEntity, Long> {
	
	Page<ContatoEntity> findAll(Pageable page);
	//select * from contato where nome = '?'		  
	List<ContatoEntity> findContatoByNome(String nome);
	List<ContatoEntity> findContatoByAlturaBetween(Double min, Double max);
	List<ContatoEntity> findContatoByIdadeInOrderByIdadeDesc(List<Integer> valores);
	
	//JPQL
	@Query(" SELECT rafa FROM ContatoEntity rafa WHERE rafa.altura BETWEEN :min AND :max ")
	List<ContatoEntity> findContatoByAlturaBetweenJPQL(Double min, Double max);
	
	@Query(" SELECT rafa FROM ContatoEntity rafa WHERE rafa.altura BETWEEN :min AND :max ")
	List<ContatoDTO> findContatoByAlturaBetweenJPQLComProjection(Double min, Double max);
 }
