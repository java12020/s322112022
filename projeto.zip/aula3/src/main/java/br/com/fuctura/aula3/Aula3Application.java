package br.com.fuctura.aula3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import br.com.fuctura.aula3.dto.ContatoRequestDTO;
import br.com.fuctura.aula3.service.IContatoService;

@SpringBootApplication
public class Aula3Application {
	
	@Qualifier("H2")
	@Autowired
	IContatoService service;
	
	public static void main(String[] args) {
		SpringApplication.run(Aula3Application.class, args);
	}
	
	@Bean
    CommandLineRunner runner() {
        return args -> {
            System.out.println("CommandLineRunner running in the UnsplashApplication class...");
            
            var c1 = new ContatoRequestDTO();
            c1.setNome("João");
            c1.setAltura(1.28);
            c1.setIdade(10);
            
            //service.salvar(c1);
        };
    }

}
