insert into contato (id, nome, altura, idade) values (1, 'Messi', 1.90, 35);
insert into contato (id, nome, altura, idade) values (2, 'Cristiano Ronaldo', 1.93, 30);
insert into contato (id, nome, altura, idade) values (3, 'Neymar', 1.92, 28);
insert into contato (id, nome, altura, idade) values (4, 'Pelé', 1.91, 82);
insert into contato (id, nome, altura, idade) values (5, 'Roberto Dinamite', 1.90, 65);