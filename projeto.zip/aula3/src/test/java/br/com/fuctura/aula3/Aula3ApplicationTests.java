package br.com.fuctura.aula3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
